package com.atguigu.lease.web.app.mapper;

import com.atguigu.lease.model.entity.FacilityInfo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.List;

/**
* @author liubo
* @description 针对表【facility_info(配套信息表)】的数据库操作Mapper
* @createDate 2023-07-26 11:12:39
* @Entity com.atguigu.lease.model.entity.FacilityInfo
*/
public interface FacilityInfoMapper extends BaseMapper<FacilityInfo> {

    /**
     * 根据房间id查询配套信息
     * @param id
     * @return
     */
    List<FacilityInfo> selectListByRoomId(Long id);

    /**
     * 根据公寓id查询配套信息
     * @param id
     * @return
     */
    List<FacilityInfo> selectListByApartmentId(Long id);
}




