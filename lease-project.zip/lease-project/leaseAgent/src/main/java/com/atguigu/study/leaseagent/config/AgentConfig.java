package com.atguigu.study.leaseagent.config;

import com.alibaba.cloud.ai.dashscope.api.DashScopeApi;
import com.alibaba.cloud.ai.memory.redis.RedisChatMemoryRepository;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.MessageWindowChatMemory;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.tool.ToolCallbackProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AgentConfig {

    @Value("${ALI_API_KEY}")
    private String apiKey;

    @Bean
    public DashScopeApi getDashScopeApi() {
        return DashScopeApi.builder().apiKey(apiKey).build();
    }

    //具有聊天记忆存储功能的chatClient
    @Bean
    public ChatClient chatClient(ChatModel chatModel,
                                 RedisChatMemoryRepository redisChatMemoryRepository,
                                 ToolCallbackProvider tools){
        //MessageWindowChatMemory规定了聊天记录上限问题
        MessageWindowChatMemory chatMemory = MessageWindowChatMemory.builder()
                .chatMemoryRepository(redisChatMemoryRepository)
                .maxMessages(100)
                .build();

        //组装ChatClient，
        return ChatClient.builder(chatModel)
                .defaultAdvisors(MessageChatMemoryAdvisor.builder(chatMemory).build())  //组装对话记忆顾问
                .defaultToolCallbacks( tools.getToolCallbacks())    //mcp协议，配置见yml文件，此处只赋能给ChatClient对象
                .build();
    }
}
