package com.atguigu.study.leaseagent.config;

import jakarta.annotation.PostConstruct;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.util.List;

@Configuration
public class RAGConfig {

    @Autowired
    private VectorStore vectorStore;  // 向量数据库

    @Value("classpath:room_detail.txt")
    private Resource knowledgeBase;

    @PostConstruct
    public void init()
    {
        // 1.读取文件
        TextReader textReader = new TextReader(knowledgeBase);
        List<Document> documents = textReader.get();
        // 2. 分割文档为块
        TokenTextSplitter splitter = new TokenTextSplitter();
        List<Document> chunks = splitter.apply(documents);
        // 3.写入向量数据库（Redis）,无法去重复版
        vectorStore.add(chunks);
    }
}
