package com.atguigu.study.leaseagent.bean;


import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
* 公寓&配套关联表
* @TableName apartment_facility
*/
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApartmentFacility implements Serializable {

    /**
    * 
    */
    @NotNull(message="[]不能为空")
    private Long id;
    /**
    * 公寓id
    */
    private Long apartmentId;
    /**
    * 设施id
    */
    private Long facilityId;
    /**
    * 创建时间
    */
    private Date createTime;
    /**
    * 更新时间
    */
    private Date updateTime;
    /**
    * 是否删除
    */
    private Integer isDeleted;

}
