package com.atguigu.study.leaseagent.service;

public interface AgentService {

}
