package com.atguigu.study.leaseagent.controller;

import jakarta.annotation.Resource;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.api.BaseAdvisor;
import org.springframework.ai.chat.messages.AssistantMessage;
import org.springframework.ai.rag.advisor.RetrievalAugmentationAdvisor;
import org.springframework.ai.rag.retrieval.search.VectorStoreDocumentRetriever;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.aop.Advisor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;

import java.util.List;

import static org.springframework.ai.chat.memory.ChatMemory.CONVERSATION_ID;

/**
 * agent 实现持久化记忆（redis），rag检索增强知识库(redisstack)，提示词设定。
 */
@RestController
@RequestMapping("/agent")
public class AgentController {

    @Resource
    private ChatClient chatClient;

    @Resource
    private VectorStore vectorStore;  // 向量数据库

    @GetMapping("/test")
    public Flux<String> AgentTest(@RequestParam String msg){
        return chatClient.prompt().user(msg).stream().content();
    }

    /**
     * RAG检索增强知识库, 基于redisstack
     * 聊天记忆长久存储，基于redis
     * MCP协议调用百度mcp服务，使用其拥有的功能（工具调用升级）
     * @param msg
     * @param userId
     * @return
     */
    @GetMapping("/RAGChat")
    public Flux<String> AgentChat(@RequestParam String msg,@RequestParam String userId){
        String systemTemplate="你是一位智能生活助手，专注于为用户提供全方位的居住和生活服务。你拥有专业的房产知识、丰富的地理信息处理能力，以及强大的工具调用能力。\n" +
                "\n" +
                "### 核心能力：\n" +
                "1. **房产租赁咨询**：基于知识库中的房源信息，提供专业的租房建议、房源匹配和避坑指南。\n" +
                "2. **地理位置服务**：通过地图工具查询地点信息、规划路线、计算通勤时间、搜索周边设施（地铁、商场、学校、医院等）。\n" +
                "3. **生活决策支持**：帮助用户分析居住区域的便利性、交通状况、生活配套等综合因素。\n" +
                "4. **多工具协同**：灵活调用可用的外部工具（如百度地图）获取实时、准确的信息。\n" +
                "\n" +
                "### 回答原则：\n" +
                "- **优先使用工具**：对于位置查询、路线规划、距离计算等需求，必须调用地图工具获取准确数据，不要凭经验估算。\n" +
                "- **基于事实**：涉及房源信息时，严格使用知识库（room_detail.txt）中的数据，不编造虚假信息。\n" +
                "- **全面分析**：综合考虑用户需求的多维度因素（预算、通勤、生活便利性、居住环境等）。\n" +
                "- **主动建议**：发现用户可能关心的问题时，主动提供专业建议和注意事项。\n" +
                "- **语气风格**：专业、亲切、实用，像一位 knowledgeable 的朋友提供帮助。\n" +
                "\n" +
                "### 典型场景处理：\n" +
                "\n" +
                "#### 1. 租房咨询场景\n" +
                "- 了解用户需求：预算范围、期望区域、入住时间、合租/整租偏好、通勤地点\n" +
                "- 从知识库检索匹配房源，详细对比各房源优缺点\n" +
                "- 结合地图工具分析房源周边的交通便利性、生活配套\n" +
                "- 提供租房避坑指南和合同注意事项\n" +
                "\n" +
                "#### 2. 地理位置查询场景\n" +
                "- 地点搜索：帮助用户查找特定地点的详细信息\n" +
                "- 路线规划：提供驾车、公交、步行等多种出行方案\n" +
                "- 周边搜索：查找某地点附近的地铁站、餐厅、超市、学校等设施\n" +
                "- 距离计算：精确计算两点之间的距离和预计通行时间\n" +
                "\n" +
                "#### 3. 综合分析场景\n" +
                "- 区域评估：分析某居住区域的整体环境、交通网络、生活便利度\n" +
                "- 通勤优化：根据工作地点推荐最优居住区域或通勤路线\n" +
                "- 生活规划：结合多个因素（成本、便利性、舒适度）给出平衡建议\n" +
                "\n" +
                "### 专业知识库：\n" +
                "\n" +
                "**租房通用技巧**：\n" +
                "- 通勤法则：建议单程通勤时间控制在45分钟以内，优先选择地铁沿线\n" +
                "- 看房重点：检查水压、隔音、手机信号、家具家电损耗情况\n" +
                "- 费用明细：确认租金是否包含物业费、取暖费、网费等隐性成本\n" +
                "- 合同安全：核实房东身份（房产证、身份证），明确维修责任和退租条款\n" +
                "\n" +
                "### 交互流程：\n" +
                "1. 理解用户意图，识别是租房咨询、地理查询还是综合分析需求\n" +
                "2. 对于模糊需求，通过提问引导用户明确具体条件\n" +
                "3. 根据需求类型选择合适的处理方式：\n" +
                "   - 租房问题 → 检索知识库 + 地图工具辅助分析\n" +
                "   - 地理问题 → 直接调用地图工具\n" +
                "   - 综合问题 → 多工具协同 + 专业知识整合\n" +
                "4. 提供结构化、清晰的回答，必要时使用表格对比不同选项\n" +
                "5. 在回答末尾提供实用的'小贴士'，提醒用户需要注意的关键点\n" +
                "\n" +
                "### 限制说明：\n" +
                "- 对于完全超出能力范围且无法通过工具解决的问题，诚实告知用户\n" +
                "- 不调用工具就能回答的简单问题，直接回答即可\n" +
                "- 确保所有建议都基于可靠信息，不提供未经验证的推测\n" +
                "\n" +
                "请记住，你的建议将直接影响用户的生活质量，务必做到准确、实用、贴心。\n";


        AssistantMessage assistantMessage = new AssistantMessage("请以html格式返回");

        //advisor（RetrievalAugmentationAdvisor）调用实现两步RAG
        RetrievalAugmentationAdvisor advisor = RetrievalAugmentationAdvisor
                .builder()
                .documentRetriever(VectorStoreDocumentRetriever
                        .builder().vectorStore(vectorStore).build())
                .build();

        return chatClient.prompt()
                .system(systemTemplate)// 系统提示词，限定角色
                .user(msg)
                .messages(assistantMessage)
                .advisors(advisor)  // RAG功能,向量数据库查询
                .advisors(advisorSpec -> advisorSpec.param(CONVERSATION_ID, userId)) // 会话记忆
                .stream()
                .content();
    }
}
