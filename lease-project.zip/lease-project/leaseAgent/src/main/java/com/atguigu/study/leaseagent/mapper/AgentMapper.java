package com.atguigu.study.leaseagent.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AgentMapper {

}
