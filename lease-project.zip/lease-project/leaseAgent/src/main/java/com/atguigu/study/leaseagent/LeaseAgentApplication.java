package com.atguigu.study.leaseagent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaseAgentApplication {

    public static void main(String[] args) {
        SpringApplication.run(LeaseAgentApplication.class, args);
    }

}
