package com.atguigu.study.leaseagent.service.impl;

import com.atguigu.study.leaseagent.service.AgentService;
import org.springframework.stereotype.Service;

@Service
public class AgentServiceImpl implements AgentService {

}
