package com.atguigu.study.leaseagent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeaseAgentApplicationTests {

    @Test
    void contextLoads() {
    }

}
